package com.qxmd.qxrecyclerview;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

/**
 * Created by chankruse on 15-01-05.
 */
public class QxRecyclerRowItemViewHolder extends RecyclerView.ViewHolder {

    public QxRecyclerRowItemViewHolder(View itemView) {
        super(itemView);
    }

    public void onViewAttachedToWindow() {
    }
}
